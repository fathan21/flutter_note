package com.dexterous.flutterlocalnotifications;

public enum RepeatInterval {
    EveryMinute,
    Hourly,
    Daily,
    Weekly
}
